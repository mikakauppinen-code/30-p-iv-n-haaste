AAMURUTIINI – julkaisuohje

Helpoin julkaisu Cloudflare Pagesiin:
1. Luo ilmainen Cloudflare-tili osoitteessa dash.cloudflare.com.
2. Avaa Workers & Pages.
3. Create application / Pages / Direct Upload.
4. Valitse tai lataa koko aamurutiini-app.zip.
5. Anna nimeksi esim. aamurutiini.
6. Deploy.
7. Avaa saamasi https://...pages.dev -osoite iPhonen Safarissa.
8. Safari > Jaa > Lisää Koti-valikkoon > avaa web-appina.

Tietosi tallentuvat tässä versiossa vain puhelimen selaimen paikalliseen tallennukseen.
